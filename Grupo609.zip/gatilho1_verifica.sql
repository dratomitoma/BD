select idJogador,nomeJogador,nGolos,tempoJogado from Jogador where idJogador=87;
INSERT INTO EstatisticasJogador (tempoJogado,golosMarcados,assistencias,passesRealizados,cortesRealizados,cartoesAmarelos,cartoesVermelhos,faltasCometidas,golosDefendidos,idJogador,idJogo) 
VALUES(15,10,5,120,27,0,0,2,0,87,35);
select idJogador,nomeJogador,nGolos,tempoJogado from Jogador where idJogador=87;