select * from Equipa where (idEquipa = 4 OR idEquipa = 10);
insert into Jogo values (41, 'Fase-de-grupos', '28/8/2022', 4, 10, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0);
select * from Equipa where (idEquipa = 4 OR idEquipa = 10);