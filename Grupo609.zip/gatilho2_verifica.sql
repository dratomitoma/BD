select * from Equipa where idTreinador=12;
INSERT INTO Equipa VALUES(12,'Equipa teste',12,15,3,17,1,10,2,2,'B','Quartos-de-final',12);
select * from Equipa where idTreinador=12;